#define MonitorWitdh 1920
#define MonitorHeight 1080

namespace pong
{
	void initialization();
	void mainLoop();
	void quitAll();
}

